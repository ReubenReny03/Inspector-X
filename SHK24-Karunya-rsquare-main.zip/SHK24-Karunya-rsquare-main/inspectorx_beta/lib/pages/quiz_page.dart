import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:inspectorx_beta/pages/confirm_sign.dart';

class QuizPage extends StatefulWidget {
  final String inspectionId;

  const QuizPage({Key? key, required this.inspectionId}) : super(key: key);

  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int _currentQuestionIndex = 0;
  late List<String> _questions = []; // Initialize _questions with an empty list
  late List<String> _answers = []; // List to store user answers

  PageController _pageController = PageController();

  @override
  void initState() {
    super.initState();
    _fetchQuestions(); // Fetch questions when the widget initializes
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _fetchQuestions() async {
    try {
      DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
          await FirebaseFirestore.instance
              .collection('ElivatorInspection')
              .doc(widget.inspectionId)
              .get();

      // Clear the questions list before populating it
      _questions = [];

      // Loop through the document fields and add questions to the list
      documentSnapshot.data()?.forEach((key, value) {
        if (key.startsWith('question')) {
          _questions.add(value.toString());
        }
      });

      setState(() {
        // Initialize answers list with the same length as questions
        _answers = List.filled(_questions.length, '');
      });
    } catch (e) {
      print("Error fetching questions: $e");
      // Display an error message to the user
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error fetching questions. Please try again later.'),
        ),
      );
    }
  }

  Future<bool> _showConfirmationDialog() async {
    return await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Confirm Final Submission'),
        content: Text('Are you sure you want to submit your answers?'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text('No'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text('Yes'),
          ),
        ],
      ),
    );
  }

  void _navigateToConfirmationPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ConfirmationPage(
          inspectionId: widget.inspectionId,
          answers: _answers, // Pass answers to ConfirmationPage
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Quiz'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: PageView.builder(
          controller: _pageController,
          itemCount: _questions.length,
          onPageChanged: (index) {
            setState(() {
              _currentQuestionIndex = index;
            });
          },
          itemBuilder: (context, index) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  _questions[index],
                  style: TextStyle(fontSize: 24.0),
                ),
                SizedBox(height: 20.0),
                TextField(
                  onChanged: (value) {
                    // Store user answers
                    _answers[index] = value;
                  },
                  decoration: InputDecoration(
                    hintText: 'Enter your answer',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20.0),
                GestureDetector(
                  onTap: () {
                    // Handle camera opening here if needed
                  },
                  child: Container(
                    padding: EdgeInsets.all(12.0),
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Icon(Icons.camera_alt, color: Colors.white),
                  ),
                ),
              ],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          if (_currentQuestionIndex < _questions.length - 1) {
            _pageController.nextPage(
              duration: Duration(milliseconds: 500),
              curve: Curves.ease,
            );
          } else {
            // Reached the end of the quiz
            bool confirmed = await _showConfirmationDialog();
            if (confirmed) {
              _navigateToConfirmationPage();
            }
          }
        },
        child: Icon(Icons.arrow_forward),
      ),
    );
  }
}
