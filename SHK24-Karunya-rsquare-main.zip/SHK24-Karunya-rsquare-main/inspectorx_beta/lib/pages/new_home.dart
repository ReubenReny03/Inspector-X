// import 'dart:html';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:inspectorx_beta/pages/audit_page.dart';
import 'package:inspectorx_beta/pages/leader_board_ui.dart';
// import 'package:inspectorx_beta/pages/home_page.dart';
// import 'package:inspectorx_beta/pages/leader_bord.dart';
// import 'package:inspectorx_beta/pages/mix_logic_ui_leaderboard.dart';
import 'package:inspectorx_beta/pages/remo_home.dart';
// import 'package:inspectorx_beta/pages/task_page.dart';
import 'package:inspectorx_beta/pages/user_profile_page.dart';

class NewHomePage extends StatefulWidget {
  const NewHomePage({super.key});
  @override
  _NewHomePageState createState() => _NewHomePageState();
}

class _NewHomePageState extends State<NewHomePage> {
  void signUserOut() {
    FirebaseAuth.instance.signOut();
  }

  int indexa = 0;
  final screens = [
    HomeGoPage(),
    const AuditSheetPage(),
    // LeaderBoard(),
    LeaderBoard(),
    UserProfilePage(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[indexa],
      bottomNavigationBar: GNav(
        gap: 8,
        selectedIndex:
            indexa, // selectedIndex should be tied to your indexa variable
        onTabChange: (value) => setState(() =>
            indexa = value), // Use indexa directly, no need for this.indexa
        tabs: const [
          GButton(
            icon: Icons.home,
            text: "Home",
          ),
          GButton(
            icon: Icons.work,
            text: "Tasks",
          ),
          GButton(
            icon: Icons.star,
            text: "Ranks",
          ),
          GButton(
            icon: Icons.person,
            text: "Settings",
          ),
        ],
      ),
    );
  }
}
