import 'package:flutter/material.dart';
import 'package:inspectorx_beta/services/database_service.dart';
// import 'package:intl/intl.dart';

import '../models/todo.dart';

class TaskPage extends StatefulWidget {
  const TaskPage({super.key});
  @override
  State<TaskPage> createState() => _TaskPageState();
}

class _TaskPageState extends State<TaskPage> {
  final DatabaseService _databaseService = DatabaseService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: _appBar(),
      body: _buidUI(),
    );
  }

  PreferredSizeWidget _appBar() {
    return AppBar(
        backgroundColor: Colors.blueAccent,
        title: const Text(
          "Brodcasting",
          style: TextStyle(
            color: Colors.white,
          ),
        ));
  }

  Widget _buidUI() {
    return SafeArea(
        child: Column(
      children: [
        _messageListView(),
      ],
    ));
  }

  Widget _messageListView() {
    return SizedBox(
      height: MediaQuery.sizeOf(context).height * 0.80,
      width: MediaQuery.sizeOf(context).width,
      child: StreamBuilder(
        stream: _databaseService.getTodos(),
        builder: (context, snapshot) {
          List todos = snapshot.data?.docs ?? [];
          if (todos.isEmpty) {
            return const Center(
              child: Text("Add a todo!"),
            );
          }
          return ListView.builder(
              itemCount: todos.length,
              itemBuilder: (context, index) {
                Todo todo = todos[index].data();
                print(todo.task);
                return Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  child: ListTile(
                    tileColor: Colors.amber,
                    title: Text(todo.task),
                  ),
                );
              });
        },
      ),
    );
  }
}
