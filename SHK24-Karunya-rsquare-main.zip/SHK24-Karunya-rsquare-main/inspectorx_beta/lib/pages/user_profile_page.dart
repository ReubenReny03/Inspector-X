import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserProfilePage extends StatefulWidget {
  @override
  _UserProfilePageState createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  late User _currentUser;
  Map<String, dynamic> _userData = {}; // Initialize with an empty map
  late List<dynamic> _inspections;
  late List<dynamic> _reviews;

  @override
  void initState() {
    super.initState();
    _currentUser = FirebaseAuth.instance.currentUser!;
    _getUserData();
  }

  Future<void> _getUserData() async {
    final String email = _currentUser.email!;
    final Map<String, dynamic> defaultUserData = {
      'name': 'User',
      'dp': '',
      'Position': 'Dev',
      'points': 0,
    };

    try {
      final Map<String, dynamic> userData = await _getUserInfo(email);
      setState(() {
        _userData = userData.isNotEmpty ? userData : defaultUserData;
        _inspections = _userData['Inspections'] ?? [];
        _reviews = _userData['Review'] ?? [];
      });
    } catch (error) {
      print('Error fetching user data: $error');
      setState(() {
        _userData = defaultUserData;
        _inspections = [];
        _reviews = [];
      });
    }
  }

  Future<Map<String, dynamic>> _getUserInfo(String email) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('User_info')
        .where('email', isEqualTo: email)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      final userData = querySnapshot.docs.first.data();
      return userData;
    } else {
      return {};
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Profile'),
      ),
      body: _userData.isNotEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CircleAvatar(
                    backgroundImage: NetworkImage(_userData['dp'] ?? ''),
                    radius: 50,
                  ),
                  SizedBox(height: 20),
                  Text(
                    _userData['name'] ?? 'Name not available',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    _userData['Position'] ?? 'Position not available',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    _currentUser.email ?? 'Email not available',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Points: ${_userData['points'] ?? 0}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Rating: ${_userData['Stars'] ?? 0}/5',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 20),
                  Text(
                    'Pending Inspections: ${_inspections.length}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Reviewed Inspections: ${_reviews.length}',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            )
          : CircularProgressIndicator(),
    );
  }
}
