import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:inspectorx_beta/pages/quiz_page.dart';

class AuditSheetPage extends StatelessWidget {
  const AuditSheetPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xff162535),
        title: Row(
          children: [
            Icon(
              Icons.assignment,
              color: Colors.white,
            ),
            SizedBox(width: 8),
            Text(
              'Inspection List',
              style: TextStyle(color: Colors.white),
            ),
          ],
        ),
      ),
      backgroundColor: const Color(0xff162535),
      body: ClipPath(
        clipper: CustomShapeClipper(),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40.0),
              topRight: Radius.circular(40.0),
            ),
          ),
          child: StreamBuilder<User?>(
            stream: FirebaseAuth.instance.authStateChanges(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }

              if (snapshot.hasData) {
                User? user = snapshot.data;
                String? email = user!.email;
                return StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('User_info')
                      .where('email', isEqualTo: email)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return Text('Error: ${snapshot.error}');
                    }

                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    }

                    List<String> inspections = [];
                    snapshot.data!.docs.forEach((doc) {
                      if (doc.exists) {
                        List<dynamic> inspectionList = doc['Inspections'];
                        if (inspectionList.isNotEmpty) {
                          inspections.addAll(inspectionList.cast<String>());
                        }
                      }
                    });

                    if (inspections.isEmpty) {
                      return Center(
                        child: Text('No inspections available.'),
                      );
                    }

                    return ListView.builder(
                      itemCount: inspections.length,
                      itemBuilder: (context, index) {
                        String inspectionId = inspections[index];
                        return ListTile(
                          title: Text('Audit $inspectionId'),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    QuizPage(inspectionId: inspectionId),
                              ),
                            );
                          },
                        );
                      },
                    );
                  },
                );
              } else {
                return Center(
                  child: Text('User not logged in.'),
                );
              }
            },
          ),
        ),
      ),
    );
  }
}

class CustomShapeClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return true;
  }
}
