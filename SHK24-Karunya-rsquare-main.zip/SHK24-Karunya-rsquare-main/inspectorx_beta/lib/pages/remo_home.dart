import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:inspectorx_beta/pages/audit_page.dart';
import 'package:inspectorx_beta/pages/leader_board_ui.dart';
import 'package:inspectorx_beta/pages/real_audit_page.dart';

class HomeGoPage extends StatefulWidget {
  final User user = FirebaseAuth.instance.currentUser!;
  HomeGoPage({Key? key}) : super(key: key);
  @override
  State<HomeGoPage> createState() => _HomeGoPageState();
}

void signUserOut() {
  FirebaseAuth.instance.signOut();
}

class _HomeGoPageState extends State<HomeGoPage> {
  late Future<Map<String, dynamic>> _userInfoFuture;
  String _userImageUrl = '';
  String _userPosition = '';
  int _userPoints = 0;

  late Future<String> _userNameFuture;
  late Future<double> _userStarsFuture;
  double _userStars = 0;
  @override
  void initState() {
    super.initState();
    _userNameFuture = _getUserName(widget.user.email!);
    _userStarsFuture = _getRatingFromDatabase(widget.user.email!);
    _userStarsFuture.then((stars) {
      setState(() {
        _userStars = stars;
        // Update the _userStars variable after fetching
      });
    });
    _userInfoFuture = _getUserInfo(widget.user.email!);
    _userInfoFuture.then((userInfo) {
      setState(() {
        _userImageUrl = userInfo['dp'];
        _userPosition = userInfo['Position'];
        _userPoints = userInfo['points'];
      });
    });
  }

  Future<Map<String, dynamic>> _getUserInfo(String email) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('User_info')
        .where('email', isEqualTo: email)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      final userData = querySnapshot.docs.first.data();
      return userData;
    } else {
      return {
        'name': 'User',
        'dp': '',
        'Position': 'Dev',
        'points': 0,
      }; // Provide default values
    }
  }

  Future<String> _getUserName(String email) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('User_info')
        .where('email', isEqualTo: email)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      final userName = querySnapshot.docs.first.get('name');
      return userName;
    } else {
      return 'User';
    }
  }

  Future<double> _getRatingFromDatabase(String email) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('User_info')
        .where('email', isEqualTo: email)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      final stars = querySnapshot.docs.first.get('Stars');
      return stars.toDouble(); // Convert to double
    } else {
      return 0; // Return 0 if no data found
    }
  }

  int currentProgress = 2;
  PreferredSizeWidget _appBar() {
    return AppBar(
      backgroundColor: const Color(0xff162535),
      title: FutureBuilder<String>(
        future: _userNameFuture,
        builder: (context, snapshot) {
          return Text(
            "Hi, ${snapshot.data}",
            style: const TextStyle(
              color: Colors.white,
            ),
          );
        },
      ),
      actions: const <Widget>[
        IconButton(
          onPressed: signUserOut,
          icon: Icon(
            Icons.logout,
            color: Colors.white,
          ),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final double width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: const Color(0xff162535),
        resizeToAvoidBottomInset: false,
        appBar: _appBar(),
        body: Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40.0),
              topRight: Radius.circular(40.0),
            ),
          ),
          child: Column(
            children: [
              const SizedBox(
                height: 25,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Positioned(
                  top: 25.0,
                  left: 10.0,
                  right: 10.0,
                  child: Container(
                    height: 150,
                    width: width,
                    decoration: const BoxDecoration(
                      color: Color(0xffFFC107),
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          left: 20,
                          top: 20,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "$_userPoints XP",
                                style: const TextStyle(
                                    color: Color(0xff1E1671), fontSize: 40),
                              ),
                              Text(
                                _userPosition,
                                style: const TextStyle(
                                    color: Color(0xff1E1671), fontSize: 15),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          bottom: 10,
                          left: 15,
                          child: RatingBar.builder(
                            initialRating: _userStars,
                            minRating: 1,
                            direction: Axis.horizontal,
                            itemSize: 20,
                            allowHalfRating: true,
                            unratedColor: Colors.white,
                            itemCount: 5,
                            itemPadding:
                                const EdgeInsets.symmetric(horizontal: 4.0),
                            itemBuilder: (context, _) => const Icon(
                              Icons.star,
                              color: Color(0xff1E1671),
                            ),
                            onRatingUpdate: (rating) {
                              // print(rating);
                            },
                          ),
                        ),
                        Positioned(
                          top: 20,
                          right: 20,
                          child: Container(
                            height: 100,
                            width: 100,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.white,
                                width: 2.0,
                              ),
                            ),
                            child: ClipOval(
                              child: Image.network(
                                _userImageUrl,
                                fit: BoxFit.cover,
                                width: 100,
                                height: 100,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Container(
                // This the the buttons area
                height: 100,
                color: Colors.white,
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const AuditSheetPage()),
                            );
                          },
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            height: 100,
                            width: 100,
                            decoration: BoxDecoration(
                              color: Color(0xffFFEDB7),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Stack(
                              children: [
                                Center(
                                  child: Image.asset(
                                    'lib/images/Tasks.png', // Replace 'your_image.png' with your actual image asset path
                                    width: 30, // Adjust width as needed
                                    height: 30, // Adjust height as needed
                                    fit: BoxFit.contain, // Adjust fit as needed
                                  ),
                                ),
                                const Positioned(
                                  bottom: 5,
                                  left: 0,
                                  right: 0,
                                  child: Center(
                                    child: Text(
                                      "Tasks",
                                      style: TextStyle(
                                        fontSize: 14,
                                        // fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => AuditPage()),
                            );
                          },
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            height: 100,
                            width: 100,
                            decoration: BoxDecoration(
                              color: Color(0xffFFEDB7),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Stack(
                              children: [
                                Center(
                                  child: Image.asset(
                                    'lib/images/Audits.png', // Replace 'your_image.png' with your actual image asset path
                                    width: 30, // Adjust width as needed
                                    height: 30, // Adjust height as needed
                                    fit: BoxFit.contain, // Adjust fit as needed
                                  ),
                                ),
                                const Positioned(
                                  bottom: 5,
                                  left: 0,
                                  right: 0,
                                  child: Center(
                                    child: Text(
                                      "Audit",
                                      style: TextStyle(
                                        fontSize: 14,
                                        // fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => LeaderBoard()),
                            );
                          },
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            height: 100,
                            width: 100,
                            decoration: BoxDecoration(
                              color: Color(0xffFFEDB7),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Stack(
                              children: [
                                Center(
                                  child: Image.asset(
                                    'lib/images/ranks-home.png', // Replace 'your_image.png' with your actual image asset path
                                    width: 30, // Adjust width as needed
                                    height: 30, // Adjust height as needed
                                    fit: BoxFit.contain, // Adjust fit as needed
                                  ),
                                ),
                                const Positioned(
                                  bottom: 5,
                                  left: 0,
                                  right: 0,
                                  child: Center(
                                    child: Text(
                                      "Rank",
                                      style: TextStyle(
                                        fontSize: 14,
                                        // fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Stack(
                children: [
                  Container(
                    height: 125,
                    color: Colors.white,
                  ),
                  const Positioned(
                    top: 10,
                    left: 10,
                    child: Text(
                      "Top Inspectors",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: GestureDetector(
                      onTap: () {
                        // Handle 'View All' button tap
                      },
                      child: const Text(
                        "View All",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Color(0xffFFC107),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 40,
                    left: 10,
                    right: 10,
                    child: SizedBox(
                      height: 75, // Adjust the height according to your needs
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: const [
                          // Replace the URLs with your image URLs
                          CircleAvatar(
                            radius: 30,
                            backgroundImage: NetworkImage(
                                'https://avatars.githubusercontent.com/u/91603618?v=4'),
                          ),
                          SizedBox(width: 10), // Adjust spacing between images
                          CircleAvatar(
                            radius: 30,
                            backgroundImage: NetworkImage(
                                'https://yt3.googleusercontent.com/ytc/AIdro_nzxtHYpPfs4szYDgpsW_-heMYzUdnI7-uRUA3z=s160-c-k-c0x00ffffff-no-rj'),
                          ),
                          SizedBox(width: 10), // Adjust spacing between images
                          // Add more CircleAvatar widgets as needed
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              // Assuming current progress is 2 out of 5
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  decoration: const BoxDecoration(
                    color: Color(0xffFFEDB7),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10.0),
                      topRight: Radius.circular(10.0),
                      bottomLeft: Radius.circular(10.0),
                      bottomRight: Radius.circular(10.0),
                    ),
                  ),
                  height: 103,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Daily Missions",
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(height: 5),
                        LinearProgressIndicator(
                          value: currentProgress /
                              5, // Convert progress to a value between 0.0 and 1.0
                          backgroundColor: Colors.white,
                          valueColor: const AlwaysStoppedAnimation<Color>(
                              Color(0xffFFC107)),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          "$currentProgress/5 Completed",
                          style: const TextStyle(
                            fontSize: 16,
                            color: Color(0xffFFC107),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ));
  }
}
