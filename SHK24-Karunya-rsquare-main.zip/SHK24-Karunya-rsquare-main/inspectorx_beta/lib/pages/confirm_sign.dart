import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:signature/signature.dart';

class ConfirmationPage extends StatefulWidget {
  final User user = FirebaseAuth.instance.currentUser!;
  final String inspectionId;
  final List<String> answers; // List to store user answers

  ConfirmationPage({
    Key? key,
    required this.inspectionId,
    required this.answers,
  }) : super(key: key);

  @override
  _ConfirmationPageState createState() => _ConfirmationPageState();
}

class _ConfirmationPageState extends State<ConfirmationPage> {
  final SignatureController _controller = SignatureController(
    penStrokeWidth: 5, // Set pen stroke width
    penColor: Colors.black, // Set pen color
  );

  late String _userId;

  @override
  void initState() {
    super.initState();
    _fetchUserId();
  }

  Future<void> _fetchUserId() async {
    // Get the current user's email
    String? email = FirebaseAuth.instance.currentUser?.email;

    if (email != null) {
      try {
        // Query User_info collection to find the document with matching email
        QuerySnapshot<Map<String, dynamic>> querySnapshot =
            await FirebaseFirestore.instance
                .collection('User_info')
                .where('email', isEqualTo: email)
                .get();

        // Extract the user ID from the document
        if (querySnapshot.docs.isNotEmpty) {
          _userId = querySnapshot.docs.first.id;
        }
      } catch (e) {
        print('Error fetching user ID: $e');
      }
    }
  }

  Future<void> _increaseUserPoints() async {
    try {
      // Query User_info collection to find the document with matching email
      QuerySnapshot<Map<String, dynamic>> querySnapshot =
          await FirebaseFirestore.instance
              .collection('User_info')
              .where('email', isEqualTo: widget.user.email)
              .get();

      // Extract the user ID from the document
      if (querySnapshot.docs.isNotEmpty) {
        String userId = querySnapshot.docs.first.id;

        // Increase the points by 50 for the user
        await FirebaseFirestore.instance
            .collection('User_info')
            .doc(userId)
            .update({
          'points': FieldValue.increment(50),
        });

        print('Points increased successfully!');
      }
    } catch (e) {
      print('Error increasing points: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Confirmation'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Please sign below:',
              style: TextStyle(fontSize: 20.0),
            ),
            SizedBox(height: 20.0),
            // Signature field widget
            Container(
              width: 300,
              height: 200,
              decoration: BoxDecoration(
                border: Border.all(),
              ),
              child: Signature(
                controller: _controller,
                height: 200,
                backgroundColor: Colors.white,
              ),
            ),
            const SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () async {
                // Capture signature as image
                final Uint8List? signatureBytes =
                    await _controller.toPngBytes();
                if (signatureBytes != null) {
                  // Remove inspection ID from "Inspections" field and move it to "review"
                  await FirebaseFirestore.instance
                      .collection('User_info')
                      .doc(_userId)
                      .update({
                    'Inspections':
                        FieldValue.arrayRemove([widget.inspectionId]),
                    'review': FieldValue.arrayUnion([widget.inspectionId]),
                  });

                  // Add answers to the "Answers" collection
                  await FirebaseFirestore.instance.collection('Answers').add({
                    'quizId': widget.inspectionId,
                    'signature': signatureBytes,
                    'answers': widget.answers,
                    'email': widget.user.email!,
                    'status': "Sent for Review" // Add user answers
                  });

                  // Increase user points
                  await _increaseUserPoints();

                  // Navigate back to the home screen
                  Navigator.pop(context);
                }
              },
              child: const Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
