import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LeaderBoard extends StatefulWidget {
  final User user = FirebaseAuth.instance.currentUser!;

  LeaderBoard({Key? key}) : super(key: key);

  @override
  State<LeaderBoard> createState() => _LeaderBoardState();
}

class _LeaderBoardState extends State<LeaderBoard> {
  late List<Map<String, dynamic>> usersData;

  @override
  void initState() {
    super.initState();
    usersData = [];
    _fetchUserData();
  }

  Future<void> _fetchUserData() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('User_info').get();
    setState(() {
      usersData = snapshot.docs.map((doc) => doc.data()).toList();
    });
  }

  PreferredSizeWidget _appBar() {
    return AppBar(
      backgroundColor: Colors.blueAccent,
      title: const Text(
        "Leaderboard",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appBar(),
      body: Column(
        children: [
          SizedBox(
            height: 200,
            child: Stack(
              children: [
                Container(
                  color: Colors.white,
                  child: Center(
                    child: Image.asset(
                      'lib/images/ranks.png', // Path to your local image
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: usersData.length,
              itemBuilder: (context, index) {
                final userData = usersData[index];
                final username = userData['name'] ?? 'Unknown';
                final points = userData['points'] ?? 0;
                final imageUrl =
                    userData['dp'] ?? ''; // Access the corresponding image URL
                return Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: [
                      Text(
                        '${index + 1}', // Assuming index 0 is the top rank
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(width: 15),
                      CircleAvatar(
                        radius: 25,
                        backgroundImage: imageUrl.isNotEmpty
                            ? NetworkImage(imageUrl) as ImageProvider<Object>?
                            : AssetImage(
                                'assets/default_avatar.png'), // Provide a default image if the URL is empty
                      ),
                      SizedBox(width: 15),
                      Text(
                        '$username',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      Spacer(),
                      Container(
                        height: 25,
                        width: 70,
                        decoration: BoxDecoration(
                          color: Colors.black12,
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: Row(
                          children: [
                            SizedBox(width: 5),
                            RotatedBox(
                              quarterTurns: 1,
                              child: Icon(
                                Icons.back_hand,
                                color: Color.fromARGB(255, 255, 187, 0),
                              ),
                            ),
                            SizedBox(width: 5),
                            Text(
                              '$points',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 10,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
