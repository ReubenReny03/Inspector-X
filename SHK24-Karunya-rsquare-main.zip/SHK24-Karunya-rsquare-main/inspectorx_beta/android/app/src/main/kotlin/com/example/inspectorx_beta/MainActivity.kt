package com.example.inspectorx_beta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
