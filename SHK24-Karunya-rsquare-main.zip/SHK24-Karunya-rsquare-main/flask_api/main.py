import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

cred = credentials.Certificate("key.json")
firebase_admin.initialize_app(cred)

db = firestore.client()

# baka@gmail.com
# Mar 22, 2024
# dr10w6QQxPbO1i0SCqSRkzANcxx1
# suko@gmail.com
# Mar 22, 2024
# l3bQztnEtUegTCb18Vw0cClV59l2
# ray@gmail.com
# Mar 17, 2024
# Mar 22, 2024
# c5oO4mDXw6WGo9bXSY9jghE9T0l2
# remo@gmail.com

data = {
    'name':'Ray',
    'email':'ray@gmail.com'
}

doc_ref = db.collection('User_info').document()
doc_ref.set(data)

print(doc_ref.id)
